'use client';

import { useEffect, useState } from 'react';
import { apiClient } from '@/lib/api-client';

export default function LoginPage() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [authUrl, setAuthUrl] = useState<string | null>(null);

  useEffect(() => {
    // No need to fetch auth_url. We'll navigate the browser to the backend
    // redirect endpoint so the Flask session cookie is set and authlib can
    // perform the normal redirect/state lifecycle.
    const redirectUri = `${window.location.origin}/auth/callback`;
    const backendRedirect = `${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api'}/auth/google/redirect?redirect_uri=${encodeURIComponent(
      redirectUri
    )}`;
    setAuthUrl(backendRedirect);
    setLoading(false);
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-light">
      <div className="w-full max-w-md p-8 bg-white rounded-lg shadow-lg">
        <h1 className="text-3xl font-poppins font-semibold mb-6 text-center">Sign In</h1>

        {loading ? (
          <div className="text-center py-8">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            <p className="text-gray-600 mt-4">Loading sign-in options...</p>
          </div>
        ) : error ? (
          <div className="p-4 mb-6 bg-red-50 border border-red-200 rounded text-red-700">
            <p className="font-semibold">Error:</p>
            <p className="text-sm mt-2">{error}</p>
            <details className="text-xs mt-3 cursor-pointer">
              <summary>Details for debugging</summary>
              <pre className="bg-gray-100 p-2 mt-2 rounded overflow-auto text-xs">
                Check browser console (F12) for full error details
              </pre>
            </details>
          </div>
        ) : authUrl ? (
          <div className="space-y-4">
            <p className="text-gray-600 text-center mb-6">
              Click the button below to sign in with your Google account:
            </p>
            <a
              href={authUrl || '#'}
              className="block w-full px-4 py-3 bg-gradient-primary text-white font-semibold rounded-lg hover:opacity-90 transition text-center"
            >
              Sign in with Google
            </a>
            <details className="text-xs text-gray-500 mt-4 cursor-pointer">
              <summary>Show auth URL (for debugging)</summary>
              <pre className="bg-gray-100 p-2 mt-2 rounded overflow-auto text-xs break-all">
                {authUrl}
              </pre>
            </details>
          </div>
        ) : null}
      </div>
    </div>
  );
}
