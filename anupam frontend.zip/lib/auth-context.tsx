'use client';

import React, { createContext, useState, useCallback, useEffect } from 'react';
import { User, AuthTokens } from '@/types';
import { apiClient } from './api-client';
import Cookies from 'js-cookie';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  loginWithGoogle: (code: string, redirectUri: string) => Promise<void>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Check if user is already logged in
  useEffect(() => {
    const checkAuth = async () => {
      const token = Cookies.get('access_token');
      if (token) {
        try {
          const userData = await apiClient.getUserProfile();
          setUser(userData.user || userData);
          setIsAuthenticated(true);
        } catch (error) {
          console.error('Failed to fetch user profile:', error);
          Cookies.remove('access_token');
          Cookies.remove('refresh_token');
        }
      }
      setIsLoading(false);
    };

    checkAuth();
  }, []);

  const loginWithGoogle = useCallback(async (code: string, redirectUri: string) => {
    try {
      setIsLoading(true);
      const response = await apiClient.handleGoogleCallback(code, redirectUri);
      if (response.data?.user) {
        setUser(response.data.user);
        setIsAuthenticated(true);
        Cookies.set('user_data', JSON.stringify(response.data.user), {
          expires: 7,
          secure: true,
          sameSite: 'strict'
        });
      }
    } catch (error) {
      console.error('Google login failed:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const logout = useCallback(async () => {
    try {
      await apiClient.logout();
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      setUser(null);
      setIsAuthenticated(false);
      Cookies.remove('user_data');
    }
  }, []);

  const refreshUser = useCallback(async () => {
    const token = Cookies.get('access_token');
    if (token) {
      try {
        const userData = await apiClient.getUserProfile();
        setUser(userData.user || userData);
        setIsAuthenticated(true);
      } catch (error) {
        console.error('Failed to refresh user:', error);
        setUser(null);
        setIsAuthenticated(false);
      }
    }
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated,
        isLoading,
        loginWithGoogle,
        logout,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = React.useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
}
