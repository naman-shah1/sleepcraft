import axios, { AxiosInstance, AxiosError } from 'axios';
import Cookies from 'js-cookie';
import { AuthTokens } from '@/types';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api';

class APIClient {
  private client: AxiosInstance;
  private tokenRefreshPromise: Promise<string> | null = null;

  constructor() {
    this.client = axios.create({
      baseURL: API_URL,
      timeout: 10000,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // Add request interceptor to include JWT token
    this.client.interceptors.request.use(
      (config) => {
        const token = this.getAccessToken();
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
      },
      (error) => Promise.reject(error)
    );

    // Add response interceptor to handle token refresh
    this.client.interceptors.response.use(
      (response) => response,
      (error) => this.handleResponseError(error)
    );
  }

  private getAccessToken(): string | null {
    return Cookies.get('access_token') || null;
  }

  private getRefreshToken(): string | null {
    return Cookies.get('refresh_token') || null;
  }

  private setTokens(tokens: AuthTokens): void {
    Cookies.set('access_token', tokens.access_token, { 
      expires: 1,
      secure: true,
      sameSite: 'strict'
    });
    Cookies.set('refresh_token', tokens.refresh_token, { 
      expires: 7,
      secure: true,
      sameSite: 'strict'
    });
  }

  private clearTokens(): void {
    Cookies.remove('access_token');
    Cookies.remove('refresh_token');
    Cookies.remove('user_data');
  }

  private async refreshAccessToken(): Promise<string | null> {
    if (this.tokenRefreshPromise) {
      return this.tokenRefreshPromise;
    }

    const refreshToken = this.getRefreshToken();
    if (!refreshToken) {
      return null;
    }

    this.tokenRefreshPromise = new Promise(async (resolve, reject) => {
      try {
        const response = await axios.post(
          `${API_URL}/auth/refresh`,
          {},
          {
            headers: {
              Authorization: `Bearer ${refreshToken}`,
            },
          }
        );

        const newToken = response.data.data?.access_token;
        if (newToken) {
          Cookies.set('access_token', newToken, {
            expires: 1,
            secure: true,
            sameSite: 'strict'
          });
          resolve(newToken);
        } else {
          this.clearTokens();
          reject(new Error('Failed to refresh token'));
        }
      } catch (error) {
        this.clearTokens();
        reject(error);
      } finally {
        this.tokenRefreshPromise = null;
      }
    });

    return this.tokenRefreshPromise;
  }

  private async handleResponseError(error: AxiosError): Promise<any> {
    const originalRequest = error.config as any;

    // If 401 and not already retried, try to refresh token
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;

      try {
        const newToken = await this.refreshAccessToken();
        if (newToken && originalRequest.headers) {
          originalRequest.headers.Authorization = `Bearer ${newToken}`;
          return this.client(originalRequest);
        }
      } catch (refreshError) {
        this.clearTokens();
        window.location.href = '/auth/login';
        return Promise.reject(refreshError);
      }
    }

    return Promise.reject(error);
  }

  // Auth endpoints
  async getGoogleAuthUrl(redirectUri: string): Promise<{ auth_url: string }> {
    const response = await this.client.get('/auth/google/url', {
      params: { redirect_uri: redirectUri },
    });
    return response.data.data;
  }

  async handleGoogleCallback(code: string, redirectUri: string): Promise<any> {
    // Use POST with form-encoded body so backend can read code from request.form
    const body = new URLSearchParams({ code, redirect_uri: redirectUri }).toString();
    const response = await this.client.post('/auth/google/callback', body, {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    });
    if (response.data.data?.tokens) {
      this.setTokens(response.data.data.tokens);
    }
    return response.data;
  }

  async handleGoogleCallbackWithState(code: string, state: string, redirectUri: string): Promise<any> {
    // Use POST with form-encoded body including state for CSRF validation
    const body = new URLSearchParams({ code, state, redirect_uri: redirectUri }).toString();
    const response = await this.client.post('/auth/google/callback', body, {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    });
    if (response.data.data?.tokens) {
      this.setTokens(response.data.data.tokens);
    }
    return response.data;
  }

  async logout(): Promise<void> {
    try {
      await this.client.delete('/auth/logout');
    } finally {
      this.clearTokens();
    }
  }

  async getUserProfile(): Promise<any> {
    const response = await this.client.get('/auth/profile');
    return response.data.data;
  }

  async updateUserProfile(data: any): Promise<any> {
    const response = await this.client.put('/auth/profile', data);
    return response.data.data;
  }

  // Product endpoints
  async getHomepage(): Promise<any> {
    const response = await this.client.get('/');
    return response.data.data;
  }

  async searchProducts(query: string, page: number = 1): Promise<any> {
    const response = await this.client.get('/search', {
      params: { q: query, page },
    });
    return response.data.data;
  }

  async getContactPage(): Promise<any> {
    const response = await this.client.get('/contact');
    return response.data.data;
  }

  async getPrivacyPage(): Promise<any> {
    const response = await this.client.get('/privacy');
    return response.data.data;
  }

  async getTermsPage(): Promise<any> {
    const response = await this.client.get('/terms');
    return response.data.data;
  }

  async getSizeGuidePage(): Promise<any> {
    const response = await this.client.get('/size-guide');
    return response.data.data;
  }

  // Cart endpoints
  async getCart(params?: { sort?: string }): Promise<any> {
    const response = await this.client.get('/cart/', { params });
    return response.data.data;
  }

  async addToCart(productId: number, quantity: number = 1): Promise<any> {
    const response = await this.client.post(`/cart/add/${productId}`, { quantity });
    return response.data;
  }

  async updateCartItem(itemId: number, quantity: number): Promise<any> {
    const response = await this.client.post(`/cart/update/${itemId}`, { quantity });
    return response.data;
  }

  async removeFromCart(itemId: number): Promise<any> {
    const response = await this.client.post(`/cart/remove/${itemId}`);
    return response.data;
  }

  // Wishlist endpoints
  async getWishlist(): Promise<any> {
    const response = await this.client.get('/cart/wishlist');
    return response.data.data;
  }

  async addToWishlist(productId: number): Promise<any> {
    const response = await this.client.post(`/cart/wishlist/add/${productId}`);
    return response.data;
  }

  async removeFromWishlist(itemId: number): Promise<any> {
    const response = await this.client.post(`/cart/wishlist/remove/${itemId}`);
    return response.data;
  }

  // Products endpoints
  async getProducts(params?: { category?: string; page?: number; per_page?: number; sort?: string }): Promise<any> {
    const response = await this.client.get('/products', { params });
    return response.data.data;
  }

  async getCategories(): Promise<any> {
    const response = await this.client.get('/products/categories');
    return response.data.data;
  }

  async getProductDetail(productId: number): Promise<any> {
    const response = await this.client.get(`/products/${productId}`);
    return response.data.data;
  }
}

export const apiClient = new APIClient();
