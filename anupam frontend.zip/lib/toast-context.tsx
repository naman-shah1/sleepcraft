'use client';

import React, { createContext, useContext, useState, ReactNode } from 'react';

type Toast = { id: string; message: string; type?: 'info' | 'success' | 'error' };

type ToastContextType = {
  toasts: Toast[];
  push: (message: string, type?: Toast['type']) => void;
  remove: (id: string) => void;
};

const ToastContext = createContext<ToastContextType | undefined>(undefined);

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within ToastProvider');
  return ctx;
}

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  function push(message: string, type: Toast['type'] = 'info') {
    const id = String(Date.now()) + Math.random().toString(36).slice(2, 8);
    const t = { id, message, type };
    setToasts((s) => [t, ...s]);
    // auto-remove after 4s
    setTimeout(() => remove(id), 4000);
  }

  function remove(id: string) {
    setToasts((s) => s.filter((t) => t.id !== id));
  }

  return (
    <ToastContext.Provider value={{ toasts, push, remove }}>
      {children}
      <div aria-live="polite" className="fixed right-4 bottom-6 z-50 flex flex-col-reverse gap-3">
        {toasts.map((t) => (
          <div key={t.id} className={`max-w-sm w-full shadow-lg rounded px-4 py-3 text-sm ${
            t.type === 'success' ? 'bg-green-50 text-green-800 border border-green-100' : t.type === 'error' ? 'bg-red-50 text-red-800 border border-red-100' : 'bg-white text-gray-800 border border-gray-100'
          }`}>
            {t.message}
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}
