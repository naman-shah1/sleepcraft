"""
Routes package for the application.
Contains all route blueprints.
"""