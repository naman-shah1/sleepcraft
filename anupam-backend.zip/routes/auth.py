import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

from flask import Blueprint, request, jsonify, session, current_app
from flask_jwt_extended import (
    create_access_token,
    create_refresh_token,
    get_jwt_identity,
    jwt_required,
    get_jwt
)
from werkzeug.security import check_password_hash
from authlib.integrations.flask_client import OAuth
from datetime import datetime, timezone
import json
import requests
from extensions import limiter

from models import db, User, AddressBook

auth_bp = Blueprint('auth', __name__)

oauth = OAuth()

def init_oauth(app):
    oauth.init_app(app)
    
    print(f"DEBUG init_oauth: client_id = {app.config['GOOGLE_CLIENT_ID']}")
    print(f"DEBUG init_oauth: client_secret = {app.config['GOOGLE_CLIENT_SECRET']}")
    print(f"DEBUG init_oauth: discovery_url = {app.config['GOOGLE_DISCOVERY_URL']}")
    
    # Warn if using placeholder secrets
    if app.config['GOOGLE_CLIENT_SECRET'] == 'your-google-client-secret':
        print("⚠️  WARNING: GOOGLE_CLIENT_SECRET is a placeholder! Set it in your .env file.")
    if app.config['GOOGLE_CLIENT_ID'].startswith('your-'):
        print("⚠️  WARNING: GOOGLE_CLIENT_ID appears to be a placeholder! Set it in your .env file.")
    
    oauth.register(
        name='google',
        client_id=app.config['GOOGLE_CLIENT_ID'],
        client_secret=app.config['GOOGLE_CLIENT_SECRET'],
        server_metadata_url=app.config['GOOGLE_DISCOVERY_URL'],
        client_kwargs={
            'scope': 'openid email profile'
        }
    )
    
    print(f"DEBUG oauth.google registered successfully")
    print(f"DEBUG oauth.google.client_id = {oauth.google.client_id}")
    print(f"DEBUG oauth.google.client_secret = {oauth.google.client_secret}")

@auth_bp.route('/google/url')
def google_login_url():
    # Return the Google OAuth authorization URL. Frontend should redirect the
    # user to this URL (or open in a popup) and then receive the callback.
    redirect_uri = request.args.get('redirect_uri')
    if not redirect_uri:
        return jsonify({
            'success': False,
            'error': 'redirect_uri query parameter is required'
        }), 400

    try:
        # Store redirect_uri in server-side session briefly so callback can return it
        session['oauth_redirect_uri'] = redirect_uri
        
        # Get client_id from app config and build auth URL manually
        client_id = current_app.config['GOOGLE_CLIENT_ID']
        scopes = 'openid email profile'
        
        # Generate state and nonce for OAuth
        import secrets
        state = secrets.token_urlsafe(32)
        nonce = secrets.token_urlsafe(16)
        session['oauth_state'] = state
        session['oauth_nonce'] = nonce
        
        # Build the authorization URL manually to ensure we use the real client_id
        auth_url = (
            'https://accounts.google.com/o/oauth2/v2/auth'
            f'?response_type=code'
            f'&client_id={client_id}'
            f'&redirect_uri={redirect_uri}'
            f'&scope={scopes.replace(" ", "+")}'
            f'&state={state}'
            f'&nonce={nonce}'
        )
        
        return jsonify({
            'success': True,
            'data': {'auth_url': auth_url}
        }), 200
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'error': f'Failed to generate auth URL: {str(e)}'
        }), 500


@auth_bp.route('/google/redirect')
def google_redirect():
    """Start the OAuth flow by redirecting the user's browser to Google's
    authorization endpoint. This endpoint is intended to be navigated to
    directly from the browser.
    
    Because we can't rely on Flask session cookies being preserved across
    the cross-site redirect from Google back to our callback, we use
    authlib's default behavior which stores state in the session, then
    use a POST-based callback that the frontend can initiate to exchange
    the code (so the session cookie is present).
    """
    redirect_uri = request.args.get('redirect_uri')
    if not redirect_uri:
        return jsonify({'success': False, 'error': 'redirect_uri query parameter is required'}), 400

    # Store redirect_uri in session for use after callback
    session['oauth_redirect_uri'] = redirect_uri
    
    # Let authlib handle the redirect. It will store state in the session.
    # The browser will be redirected to Google, then Google redirects back to
    # /api/auth/google/callback?code=...&state=...
    # Because that's a GET request from Google's servers (not the browser),
    # the browser's session cookie won't be sent.
    # Solution: Have the frontend capture the code/state and POST it back
    # to the callback endpoint as form data, so the browser sends the cookie.
    return oauth.google.authorize_redirect(redirect_uri)

@auth_bp.route('/google/callback', methods=['GET', 'POST'])
def google_authorize():
    try:
        # Support both GET (query params) and POST (form-encoded body) exchanges.
        # For POST requests from the frontend, manually exchange the code.
        # For GET requests (direct from Google), try authlib's authorize_access_token.
        
        if request.method == 'POST':
            # Frontend POST: code, state, redirect_uri in form data
            # Manual token exchange to avoid session dependency
            code = request.form.get('code')
            state = request.form.get('state')
            redirect_uri = request.form.get('redirect_uri')
            
            print(f"DEBUG google_authorize POST: code={code[:20] if code else 'MISSING'}..., state={state}, redirect_uri={redirect_uri}")
            
            if not code:
                return jsonify({'success': False, 'error': 'Missing code in POST body'}), 400
            
            # Get OAuth2 token endpoint and exchange code manually
            # This bypasses authlib's state validation which relies on session
            config_url = current_app.config['GOOGLE_DISCOVERY_URL']
            config_resp = requests.get(config_url)
            config_data = config_resp.json()
            token_endpoint = config_data['token_endpoint']
            
            # Exchange code for token
            token_data = {
                'code': code,
                'client_id': current_app.config['GOOGLE_CLIENT_ID'],
                'client_secret': current_app.config['GOOGLE_CLIENT_SECRET'],
                'redirect_uri': redirect_uri,
                'grant_type': 'authorization_code'
            }
            
            print(f"DEBUG: Exchanging code at {token_endpoint}...")
            print(f"DEBUG: Token request params: client_id={token_data['client_id'][:20]}..., has_secret={bool(token_data['client_secret'])}, redirect_uri={redirect_uri}, code={code[:20] if code else 'MISSING'}...")
            
            try:
                token_resp = requests.post(token_endpoint, data=token_data)
                token_resp.raise_for_status()
                token = token_resp.json()
                print(f"DEBUG: Token exchange successful, got access_token")
            except requests.exceptions.HTTPError as e:
                print(f"DEBUG: Token exchange failed with status {token_resp.status_code}")
                error_detail = token_resp.text
                try:
                    error_json = token_resp.json()
                    error_detail = error_json.get('error_description', error_json.get('error', error_detail))
                except:
                    pass
                print(f"DEBUG: Error detail: {error_detail}")
                
                # Common issues:
                # - "invalid_grant": Code expired (>10 min old) or already used
                # - "invalid_client": Client secret is wrong
                # - "redirect_uri_mismatch": Redirect URI not registered
                
                if 'invalid_grant' in error_detail:
                    error_msg = 'Authorization code expired or already used. Please try signing in again.'
                elif 'invalid_client' in error_detail:
                    error_msg = 'OAuth client configuration error. Check GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET.'
                elif 'redirect_uri_mismatch' in error_detail:
                    error_msg = 'Redirect URI not registered in Google Cloud Console.'
                else:
                    error_msg = f'Token exchange failed: {error_detail}'
                
                return jsonify({'success': False, 'error': error_msg}), 400
            
            print(f"DEBUG: Token exchange successful, got access_token")
            
            # Parse ID token to get user info
            from authlib.jose import jwt
            # Get the public key for verification
            jwks_uri = config_data['jwks_uri']
            resp = oauth.google.parse_id_token(token, None)
        else:
            # GET request (direct from Google): use authlib's authorize_access_token
            # This will validate state from session
            print(f"DEBUG google_authorize GET: args keys={list(request.args.keys())}")
            token = oauth.google.authorize_access_token()
            resp = oauth.google.parse_id_token(token, None)
        
        user = User.get_or_create_oauth_user(
            oauth_provider='google',
            oauth_id=resp['sub'],
            email=resp['email'],
            name=resp.get('name', resp['email'].split('@')[0]),
            profile_picture=resp.get('picture')
        )
        # Create JWT tokens for the user (OAuth users do not have local passwords)
        access_token = create_access_token(
            identity=user.user_id,
            fresh=True,
            additional_claims={'email': user.email, 'name': user.name}
        )
        refresh_token = create_refresh_token(
            identity=user.user_id,
            additional_claims={'email': user.email, 'name': user.name}
        )

        # Set httpOnly cookies with the tokens so subsequent API requests
        # from the frontend can be authenticated by cookie. For local
        # development we avoid Secure=True so cookies can be set over http://localhost.
        from flask import make_response, redirect

        # Default redirect target is the session-stored oauth_redirect_uri
        redirect_uri = session.pop('oauth_redirect_uri', None) or request.args.get('redirect_uri')

        # If this was an XHR/POST request (frontend exchanged code directly),
        # return JSON and also set cookies.
        if request.method == 'POST':
            resp = make_response(jsonify({
                'success': True,
                'data': {
                    'user': {
                        'id': user.user_id,
                        'name': user.name,
                        'email': user.email,
                        'profile_picture': user.profile_picture,
                        'is_verified': user.is_verified,
                        'oauth_provider': user.oauth_provider
                    },
                    'tokens': {
                        'access': access_token,
                        'refresh': refresh_token
                    }
                }
            }), 200)
            # Set cookies (httpOnly)
            resp.set_cookie('access_token', access_token, httponly=True, samesite='Lax')
            resp.set_cookie('refresh_token', refresh_token, httponly=True, samesite='Lax')
            return resp

        # Otherwise this is a browser redirect from Google (GET). Set cookies
        # and then redirect the browser to the frontend redirect_uri carrying
        # the tokens in the URL fragment so the frontend can also set non-httpOnly
        # cookies if it wants to
        fragment = f"#access={access_token}&refresh={refresh_token}"
        target = redirect_uri or '/'
        # Ensure fragment is appended correctly
        if '#' in target:
            target = target.split('#')[0]
        redirect_target = f"{target}{fragment}"

        resp = make_response(redirect(redirect_target))
        resp.set_cookie('access_token', access_token, httponly=True, samesite='Lax')
        resp.set_cookie('refresh_token', refresh_token, httponly=True, samesite='Lax')
        return resp
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        # In development return the exception message to help debugging
        return jsonify({
            'success': False,
            'error': 'Failed to sign in with Google',
            'exception': str(e)
        }), 500

# NOTE: local login/signup endpoints have been removed. Authentication
# is handled exclusively via OAuth (Google) and JWT tokens.

@auth_bp.route('/profile', methods=['GET', 'PUT'])
@jwt_required()
def profile():
    current_user_id = get_jwt_identity()
    user = User.query.get_or_404(current_user_id)
    
    if request.method == 'GET':
        addresses = AddressBook.query.filter_by(user_id=user.user_id).all()
        return jsonify({
            'success': True,
            'data': {
                'user': {
                    'id': user.user_id,
                    'name': user.name,
                    'email': user.email,
                    'mobile_number': user.mobile_number,
                    'type_of_product': user.type_of_product,
                    'profile_picture': user.profile_picture,
                    'is_verified': user.is_verified,
                    'oauth_provider': user.oauth_provider
                },
                'addresses': [
                    {
                        'id': addr.address_id,
                        'address': addr.address
                    } for addr in addresses
                ]
            }
        }), 200
    
    try:
        data = request.get_json()
        name = data.get('name', '').strip()
        email = data.get('email', '').strip().lower()
        type_of_product = data.get('type_of_product', '').strip()
        addresses = data.get('addresses', [])
        
        if not name or not email:
            return jsonify({
                'success': False,
                'error': 'Name and email are required'
            }), 400
        
        # Validate email uniqueness if changed
        if email != user.email:
            if User.query.filter_by(email=email).first():
                return jsonify({
                    'success': False,
                    'error': 'Email already in use'
                }), 400

        # Update user fields
        user.name = name
        user.email = email
        user.type_of_product = type_of_product
        
        # Update addresses
        AddressBook.query.filter_by(user_id=user.user_id).delete()
        for addr in addresses:
            if addr.strip():
                new_addr = AddressBook(user_id=user.user_id, address=addr.strip())
                db.session.add(new_addr)

        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Profile updated successfully'
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@auth_bp.route('/refresh', methods=['POST'])
@jwt_required(refresh=True)
def refresh():
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({
                'success': False,
                'error': 'User not found'
            }), 404
        
        # Create new access token
        access_token = create_access_token(
            identity=user.user_id,
            fresh=False,
            additional_claims={
                'name': user.name,
                'email': user.email,
                'type': 'access'
            }
        )
        
        return jsonify({
            'success': True,
            'data': {
                'access_token': access_token
            }
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@auth_bp.route('/logout', methods=['DELETE'])
@jwt_required()
def logout():
    try:
        jwt_data = get_jwt()
        jti = jwt_data['jti']
        exp_timestamp = jwt_data['exp']
        
        from utils.token_blocklist import add_to_blocklist
        if add_to_blocklist(jti, exp_timestamp):
            return jsonify({
                'success': True,
                'message': 'Successfully logged out'
            }), 200
        else:
            return jsonify({
                'success': False,
                'error': 'Error adding token to blocklist'
            }), 500
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500