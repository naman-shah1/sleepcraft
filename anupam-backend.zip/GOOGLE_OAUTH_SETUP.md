# Google OAuth Setup Guide for SleepCraft

## Current Status
❌ **Your GOOGLE_CLIENT_SECRET is still a placeholder!**

The `.env` file shows:
```
GOOGLE_CLIENT_SECRET=your-google-client-secret
```

This needs to be replaced with your real Google Client Secret from the Google Cloud Console.

## Steps to Get Your Google Client Secret

### 1. Go to Google Cloud Console
- Navigate to: https://console.cloud.google.com/
- Select your project (or create one if you don't have one)

### 2. Enable Google+ API
- In the search bar, search for "Google+ API"
- Click on it and press "Enable"

### 3. Create OAuth Credentials
- Go to **Credentials** in the left menu
- Click **+ Create Credentials** → **OAuth client ID**
- If prompted, configure the OAuth consent screen first:
  - Choose "External" as the user type
  - Fill in the required fields (app name, user support email, etc.)
  - Add scopes: `openid`, `email`, `profile`
  - Add test users if in development

### 4. Create OAuth 2.0 Client ID
- Application type: **Web application**
- Name: `SleepCraft Local` (or whatever you prefer)
- **Authorized JavaScript origins** (add all):
  - `http://localhost:5000` (Flask backend)
  - `http://localhost:3000` (Next.js frontend)
  - `http://127.0.0.1:5000`
  - `http://127.0.0.1:3000`

- **Authorized redirect URIs** (add all):
  - `http://localhost:5000/api/auth/google/callback`
  - `http://localhost:3000/auth/callback`
  - `http://127.0.0.1:5000/api/auth/google/callback`
  - `http://127.0.0.1:3000/auth/callback`

### 5. Copy Your Credentials
- After creating, you'll see a popup with:
  - **Client ID**: (already in your .env ✓)
  - **Client Secret**: **COPY THIS**

### 6. Update .env File
Update your `.env` file:
```properties
GOOGLE_CLIENT_ID=550481205827-8ll8ut8cm3v5lqhcgm7hi6fmfk23ov2r.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=<YOUR_REAL_SECRET_HERE>
```

Replace `<YOUR_REAL_SECRET_HERE>` with the actual secret from Google Cloud Console.

⚠️ **IMPORTANT**: Never commit the real secret to Git! Add `.env` to `.gitignore`.

## Testing the OAuth Flow

1. **Restart Flask server:**
   ```powershell
   Ctrl+C  # Stop current server
   python app.py
   ```

2. **Visit the login page:**
   - Open http://localhost:3000/auth/login
   - Click "Sign in with Google"
   - Complete Google sign-in
   - You should be redirected to the homepage

3. **Verify success:**
   - Check browser DevTools → Application → Cookies
   - You should see `access_token` and `refresh_token` cookies
   - Profile page should show your Google account info

## Troubleshooting

### "Invalid client" error
- Client Secret is wrong or placeholder
- Check you copied the correct secret from Google Cloud

### "Redirect URI mismatch"
- The redirect URI in the request doesn't match what's registered in Google Cloud
- Make sure `http://localhost:3000/auth/callback` and `http://localhost:5000/api/auth/google/callback` are registered

### "State mismatch" error
- This typically means Flask session isn't being preserved
- Check browser console for network requests
- Make sure cookies are being set

### CORS errors
- Frontend and backend might be on different ports
- Verify `CORS_ORIGINS=http://localhost:3000` in `.env`
- Check Flask CORS config in `app.py`

## Need Help?

Common issues and solutions are documented in the troubleshooting section above.
